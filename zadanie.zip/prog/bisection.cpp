#include "constants.h"

typedef<typename Lambda>
std::vetor<double&> & bisection(Lambda & f, double a, double b, int iterations = 2) {
  double m;
  std::vector<double*> results;
  do {
    m = (b-a)/2;
    if (f(a)*f(m) < 0) {
      b = m;
    } else {
      a = m;
    }
    results.push({m, f(m)});
  } while (abs(f(m)) > E && iterations >= results.size());
  return results;
}