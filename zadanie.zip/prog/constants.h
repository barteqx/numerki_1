#include <cmath>

K = (sqrt(5)-1)/2;

E = 10e-10;

PI = 3.14159265359;