#include "constants.h"

typedef<typename Lambda>
std::vetor<double&> & golden_section(Lambda & f, double a, double b, bool min, int iterations = 20) {
  double x_L, x_R, l;
  std::vector<double*> results;
  do {
    l = K*(b-a);
    x_R = a + l;
    x_L = b - l;
    if min {
      if (f(x_L) > f(x_R)) {
        a = x_L;
      } else {
        b = x_R;
      }
    } else {
      if (f(x_L) > f(x_R)) {
        b = x_R;
      } else {
        a = x_L;
      }
    }
    results.push({(b-a)/2, f((b-a)/2)});
  } while (b - a > E && iterations >= results.size());
  return results;
}