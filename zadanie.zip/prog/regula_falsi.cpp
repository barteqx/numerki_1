#include "constants.h"

typedef<typename Lambda>
std::vetor<double&> & newton(Lambda & f, double a, double b, int iterations = 20) {
  x = (a*f(b) - b*f(a))/(f(b) - f(a));
  double x_next;
  std::vector<double*> results;
  results.push({x, f(x)});
  do {
    if (f(a)*f(x) <= 0) {
      x_next = (x*f(b) - b*f(x))/(f(b) - f(x));
    } else if (f(x)*f(b) < 0) {
      x_next = (a*f(x) - x*f(a))/(f(x) - f(a));
    }
    x_next = x - (f(x)/d(x));
    results.push({x_next, f(x_next)});
  } while (abs(f(x_next)) > E && iterations >= results.size());
  return results;
}