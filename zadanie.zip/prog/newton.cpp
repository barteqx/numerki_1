#include "constants.h"

typedef<typename Lambda>
std::vetor<double&> & newton(Lambda & f, Lambda & d, double x, int iterations = 20) {
  double x_next;
  std::vector<double*> results;
  do {
    x_next = x - (f(x)/d(x));
    results.push({x_next, f(x_next)});
  } while (abs(f(x_next)) > E && iterations >= results.size());
  return results;
}